function y = Bi( x )
%BI Summary of this function goes here
%   Detailed explanation goes here
y=(1+sign(sin(x+pi)))*0.5;

end

